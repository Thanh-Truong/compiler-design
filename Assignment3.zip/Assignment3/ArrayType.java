
public class ArrayType extends Type {
	private Id m_typeOfArray;
	
	public ArrayType() {
		super();
	}

	public Id getTypeOfArray() {
		return m_typeOfArray;
	}

	public void setTypeOfArray(Id typeOfArray) {
		m_typeOfArray = typeOfArray;
	}
	
}
