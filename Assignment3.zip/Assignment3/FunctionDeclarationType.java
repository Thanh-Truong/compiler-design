
public class FunctionDeclarationType extends Type {

	public FunctionDeclarationType() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	private int m_numberOfParameters;
	
	public int getNumberOfParameters() {
		return m_numberOfParameters;
	}
	public void setNumberOfParameters(int numberOfParameters) {
		m_numberOfParameters = numberOfParameters;
	}
	
}
